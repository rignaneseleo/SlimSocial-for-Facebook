## Reporting a Vulnerability

If you discover a security vulnerability within Jest, please submit a report via the GitHub's [Private Vulnerability Reporting](https://github.com/jestjs/jest/security/advisories) feature.

All security vulnerabilities will be promptly addressed.
