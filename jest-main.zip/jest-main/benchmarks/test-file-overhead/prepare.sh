#!/usr/bin/env sh
for i in {1..499}; do
  cp 0.test.js $i.test.js
done
