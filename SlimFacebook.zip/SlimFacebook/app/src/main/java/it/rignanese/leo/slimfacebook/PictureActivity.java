package it.rignanese.leo.slimfacebook;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.widget.Toast;

import it.rignanese.leo.slimfacebook.utility.MyAdvancedWebView;


/**
 * SlimSocial for Facebook is an Open Source app realized by Leonardo Rignanese <rignanese.leo@gmail.com>
 * GNU GENERAL PUBLIC LICENSE  Version 2, June 1991
 * GITHUB: https://github.com/rignaneseleo/SlimSocial-for-Facebook
 */

public class PictureActivity extends Activity implements MyAdvancedWebView.Listener {
    private MyAdvancedWebView webViewPicture;//the main webView where is shown facebook
    private SharedPreferences savedPreferences;//contains all the values of saved preferences

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);

        savedPreferences = PreferenceManager.getDefaultSharedPreferences(this); // setup the sharedPreferences

        SetupPictureWebView();

        String pictureUrl = getIntent().getStringExtra("URL");
        webViewPicture.loadUrl(pictureUrl);
    }


    private void SetupPictureWebView() {
        webViewPicture = (MyAdvancedWebView) findViewById(R.id.webViewPicture);
        webViewPicture.setListener(this, this);

      //  webViewPicture.setDesktopMode(true);

        //webViewPicture.requestFocus(View.F);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);//remove the keyboard issue


        WebSettings settings = webViewPicture.getSettings();

        settings.setBuiltInZoomControls(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptEnabled(true);
        settings.setLoadWithOverviewMode(true);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            // Hide the zoom controls for HONEYCOMB+
            settings.setDisplayZoomControls(false);
        }
    }

    //*********************** MENU ****************************
    //add my menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.picture_menu, menu);
        return true;
    }

    //handling the tap on the menu's items
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.download: {//scroll on the top of the page
               DownloadPicture(webViewPicture.getUrl());
            }
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void DownloadPicture(String url) {
        //check permission
        if (Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            //ask permission
            Toast.makeText(getApplicationContext(), getString(R.string.acceptPermissionAndRetry),
                    Toast.LENGTH_LONG).show();
            int requestResult = 0;
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, requestResult
            );
        } else {
            //download photo
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle("SlimSocial Download");
            // in order for this if to run, you must use the android 3.2 to compile your app
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                request.allowScanningByMediaScanner();
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            }


            String path = Environment.DIRECTORY_DOWNLOADS;
            if (savedPreferences.getBoolean("pref_useSlimSocialSubfolderToDownloadedFiles", false)) {
                path += "/SlimSocial";
            }

            //get the name
            int itemsNumber=url.split("/").length;
            String fileName=url.split("/")[itemsNumber-1];
            fileName=fileName.substring(0,fileName.indexOf(".jpg"));

            request.setDestinationInExternalPublicDir(path, fileName+".jpg");

            //request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_HIDDEN);

            // get download service and enqueue file
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);

            Toast.makeText(getApplicationContext(), getString(R.string.downloadingPhoto),
                    Toast.LENGTH_LONG).show();


            //to share
            /*
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/jpg");
            intent.putExtra(Intent.EXTRA_STREAM, path+"/"+fileName+".jpg");
            startActivity(Intent.createChooser(intent , "Share"));
            */
        }
    }

    @Override
    public void onPageStarted(String url, Bitmap favicon) {

    }

    @Override
    public void onPageFinished(String url) {

    }

    @Override
    public void onPageError(int errorCode, String description, String failingUrl) {

    }

    @Override
    public void onDownloadRequested(String url, String suggestedFilename, String mimeType, long contentLength, String contentDisposition, String userAgent) {

    }

    @Override
    public void onExternalPageRequest(String url) {

    }

    @Override
    public boolean onUrlReceived(String url) {
        return true;
    }
}
